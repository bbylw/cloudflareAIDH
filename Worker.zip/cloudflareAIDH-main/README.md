# AIDH
chatGPT生成的可以部署在cloudflare的免费导航页

直接粘贴Workers里面编辑代码即可部署或者下载worker.zip上传Pages

演示 ： https://dh.free4.dns.army/

也可连接github 通过这个仓库https://github.com/bbylw/cloudflarefreeDH-AI 复刻到自己的仓库 通过Pages部署

可以通过https://dynv6.com/       这个域名服务商绑定免费域名

